#!/bin/bash

#Change commas to tabs, but not those within quotes (this has to be done because sqlite3 does not ignore commas within quotes in csv and will make too many columns). Then remove double quotes when and only when they surround the entire column cell (we use tab to find these). Dump this into a dummy file
sed -e ':a;s/^\(\("[^"]*"\|[^",]*\)*\),/\1\t/;ta' -e $'s/\t\"/\t/g' -e $'s/\"\t/\t/g' source/articles.csv > source/dummy.csv

#drop tables in case this script has to be run more than once
sqlite3 libcarp.sqlite3 "DROP TABLE IF EXISTS articles"
sqlite3 libcarp.sqlite3 "DROP TABLE IF EXISTS journals"

#Create table articles
sqlite3 libcarp.sqlite3 "CREATE TABLE articles (id INTEGER, Title TEXT, Authors TEXT, DOI TEXT, URL TEXT, Subjects TEXT, ISSNs TEXT, Citation TEXT, LanguageId INTEGER, LicenceId INTEGER, Author_Count INTEGER, First_Author TEXT, Citation_Count INTEGER, Day INTEGER, Month INTEGER, Year INTEGER)"

#Import articles from dummy using tab as -separator (note that tab cannot be '\t' but has to actually be tab (ascii 09)!!)
sqlite3 -separator '	' libcarp.sqlite3 ".import source/dummy.csv articles"

#remove dummy file
rm source/dummy.csv

#do the same for 'journals.csv' as above

sed -e ':a;s/^\(\("[^"]*"\|[^",]*\)*\),/\1\t/;ta' -e $'s/\t\"/\t/g' -e $'s/\"\t/\t/g' source/journals.csv > source/dummy.csv

sqlite3 libcarp.sqlite3 "CREATE TABLE journals (id INTEGER, ISSN_L TEXT, ISSNs TEXT, PublisherId INTEGER, Journal_Title TEXT)" 
#Note that in journals.csv the column name "ISSN-L" has the illegal "-" character, we substitute with "_" 

sqlite3 -separator '	' libcarp.sqlite3 ".import source/dummy.csv journals"

rm source/dummy.csv
