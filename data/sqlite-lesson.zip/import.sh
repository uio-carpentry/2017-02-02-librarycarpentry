#!/bin/bash

#drop tables in case this script has to be run more than once
sqlite3 libcarp.sqlite3 "DROP TABLE IF EXISTS articles"
sqlite3 libcarp.sqlite3 "DROP TABLE IF EXISTS journals"
sqlite3 libcarp.sqlite3 "DROP TABLE IF EXISTS languages"
sqlite3 libcarp.sqlite3 "DROP TABLE IF EXISTS licences"
sqlite3 libcarp.sqlite3 "DROP TABLE IF EXISTS publishers"

#Create tables
sqlite3 libcarp.sqlite3 "CREATE TABLE articles (id INTEGER, Title TEXT, Authors TEXT, DOI TEXT, URL TEXT, Subjects TEXT, ISSNs TEXT, Citation TEXT, LanguageId INTEGER, LicenceId INTEGER, Author_Count INTEGER, First_Author TEXT, Citation_Count INTEGER, Day INTEGER, Month INTEGER, Year INTEGER)"
sqlite3 libcarp.sqlite3 "CREATE TABLE journals (id INTEGER, ISSN_L TEXT, ISSNs TEXT, PublisherId INTEGER, Journal_Title TEXT)" 
sqlite3 libcarp.sqlite3 "CREATE TABLE languages (id INTEGER, language TEXT)" 
sqlite3 libcarp.sqlite3 "CREATE TABLE licences (id INTEGER, licence TEXT)" 
sqlite3 libcarp.sqlite3 "CREATE TABLE publishers (id INTEGER, publisher)" 


for NAME in articles journals languages licences publishers
do
	#Change commas to tabs, but not those within quotes (this has to be done because sqlite3 does not ignore commas within quotes in csv and will make too many columns). Then remove double quotes when and only when they surround the entire column cell (we use tab to find these). Skip the first line (header info) and dump this into a dummy file.
	sed -e ':a;s/^\(\("[^"]*"\|[^",]*\)*\),/\1\t/;ta' -e $'s/\t\"/\t/g' -e $'s/\"\t/\t/g' -e '1d' source/$NAME.csv > source/dummy.csv

	#Import file into table using tab as -separator (note that tab cannot be '\t' but has to actually be tab (ascii 09)!!)
	sqlite3 -separator '	' libcarp.sqlite3 ".import source/dummy.csv $NAME"

	#remove dummy file
	rm source/dummy.csv

done